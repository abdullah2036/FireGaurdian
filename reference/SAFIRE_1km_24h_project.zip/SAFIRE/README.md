# SAFIRE — Saudi Arabia Fire Early Warning System

نسخة أولية قابلة للتشغيل لرصد البؤر الحرارية في المملكة من NASA FIRMS، مع بنية أولية لإضافة نموذج تنبؤ مكاني.

## 1) المتطلبات
- Python 3.10 أو أحدث.
- اتصال بالإنترنت.
- NASA FIRMS MAP_KEY مجاني: https://firms.modaps.eosdis.nasa.gov/api/map_key/

## 2) التشغيل محلياً

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

أدخلي MAP_KEY في الشريط الجانبي داخل التطبيق. لا تضعي المفتاح في ملفات الكود أو تنشريه في مستودع عام.

## 3) ما الذي يعمل في هذه النسخة؟
- استدعاء NASA FIRMS area API لمصادر VIIRS NRT.
- استعلام ضمن صندوق جغرافي تقريبي يغطي السعودية.
- عرض النقاط على خريطة تفاعلية.
- إظهار الثقة وFRP وتاريخ/وقت الرصد.
- تصدير النتائج إلى CSV.
- واجهة تحميل شبكة خصائص مكانية إلى نموذج مدرّب، إذا توفر.

NASA FIRMS API:
https://firms.modaps.eosdis.nasa.gov/api/
تحتاج خدمات API إلى MAP_KEY. راجعي الوثائق وحدود الاستخدام الحالية.

## 4) التنبؤ: ما المطلوب قبل تفعيله؟
لا يوجد نموذج مدرّب مرفق، ولا يصح الادعاء بوجود تنبؤ حقيقي دون بيانات تدريب موثوقة. يجب إعداد ملف تاريخي يحتوي صفوفاً لكل خلية مكانية وفترة زمنية، بالأعمدة التالية:

- `temperature_c`
- `relative_humidity_pct`
- `wind_speed_m_s`
- `precipitation_mm`
- `ndvi`
- `slope_deg`
- `landcover_code`
- `month`
- `fire_next_24h` (الهدف: 1 أو 0)

مثال هيكل البيانات: `data/training_schema.csv`.

بعد تجهيز البيانات:
```bash
python train_model.py --input data/your_labeled_training_data.csv
```

سينتج الملف `models/fire_risk_model.joblib`. ثم يمكن رفع CSV لخلايا التنبؤ من تبويب «خريطة مخاطر التنبؤ».

**مهم:** `train_test_split` في السكربت الحالي للتجربة الأولية فقط. في الدراسة العلمية يجب استخدام فصل زمني ومكاني مستقل (spatiotemporal holdout)، ومعالجة عدم توازن الفئات، وفحص calibration، وقياس precision/recall وPR-AUC، ومقارنة النموذج بخط أساس. لا تستخدميه كإنذار رسمي قبل التحقق المستقل.

## 5) مصادر بيانات موصى بها
- NASA FIRMS: بؤر حرارية نشطة من MODIS وVIIRS.
- NASA POWER: متغيرات الأرصاد والطاقة الشمسية اليومية/الساعية حسب المنتج.
- بيانات الغطاء الأرضي وNDVI: مصدر موثق ومناسب للدراسة، مع توثيق الدقة المكانية والزمنية.
- نموذج الارتفاع الرقمي DEM لاشتقاق الانحدار والارتفاع.

NASA POWER docs: https://power.larc.nasa.gov/docs/services/api/temporal/daily/

## 6) حدود علمية وتشغيلية
- البؤرة الحرارية ليست بالضرورة حريق غطاء نباتي؛ قد تكون منشأة صناعية أو نشاطاً حرارياً آخر.
- غياب الرصد الفضائي لا يعني غياب الحريق؛ توجد قيود مرتبطة بمرور القمر، السحب، الدخان، وحجم الحريق.
- بيانات NRT أولية وقد تتغير عند نشر المنتجات القياسية.
- FIRMS لا يضمن إنذاراً فورياً ولا بديلاً عن الدفاع المدني أو أنظمة الرصد الأرضية.
- حدود الصندوق الجغرافي تقريبية وليست حدوداً إدارية رسمية للسعودية.
- يلزم إضافة سجل زمني، مراقبة فشل API، تنبيهات متعددة القنوات، صلاحيات مستخدمين، وسجل تدقيق قبل النشر.

## 7) الهيكل
```text
SAFIRE/
├── app.py
├── safire_data.py
├── safire_model.py
├── train_model.py
├── requirements.txt
├── README.md
├── data/
└── models/
```


ملاحظة API: واجهة FIRMS Area API تقبل نطاقاً من يوم إلى 5 أيام لكل طلب؛ لذلك حُدّدت واجهة التطبيق بهذا الحد وفق وثائق NASA.
