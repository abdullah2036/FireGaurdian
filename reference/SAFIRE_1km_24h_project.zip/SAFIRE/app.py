import io
import os
from pathlib import Path

import folium
import pandas as pd
import streamlit as st
from streamlit_folium import st_folium

from safire_data import fetch_firms_fires, normalize_fires, SAUDI_BBOX
from safire_model import FEATURES, load_model, predict_grid

st.set_page_config(page_title="SAFIRE | Saudi Fire Early Warning", page_icon="🔥", layout="wide")

st.title("SAFIRE")
st.caption("Saudi Arabia Fire Intelligence & Risk Early Warning System | نموذج أولي")

with st.sidebar:
    st.header("إعدادات الرصد")
    api_key = st.text_input(
        "NASA FIRMS MAP_KEY",
        type="password",
        help="احصلي على مفتاح مجاني من https://firms.modaps.eosdis.nasa.gov/api/map_key/"
    )
    sensor = st.selectbox(
        "مصدر بيانات VIIRS",
        ["VIIRS_NOAA20_NRT", "VIIRS_NOAA21_NRT", "VIIRS_SNPP_NRT"],
        index=0
    )
    days = st.slider("الفترة الزمنية (أيام)", min_value=1, max_value=5, value=1)
    st.caption("نطاق البحث: الحدود الجغرافية التقريبية للمملكة العربية السعودية.")
    refresh = st.button("تحديث بيانات الحرائق", type="primary", use_container_width=True)

if "fires" not in st.session_state:
    st.session_state.fires = None

if refresh:
    if not api_key.strip():
        st.error("أدخلي NASA FIRMS MAP_KEY أولاً.")
    else:
        with st.spinner("جارٍ جلب بيانات NASA FIRMS..."):
            try:
                raw = fetch_firms_fires(api_key.strip(), sensor, days)
                st.session_state.fires = normalize_fires(raw)
                st.success(f"تم استلام {len(st.session_state.fires):,} سجل.")
            except Exception as exc:
                st.error(f"تعذر جلب البيانات: {exc}")

fires = st.session_state.fires

tab_live, tab_risk, tab_method = st.tabs(
    ["الرصد المباشر", "خريطة مخاطر التنبؤ", "المنهجية والقيود"]
)

with tab_live:
    if fires is None:
        st.info("أدخلي مفتاح NASA FIRMS من الشريط الجانبي ثم اضغطي «تحديث بيانات الحرائق».")
    else:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("عدد البؤر المرصودة", f"{len(fires):,}")
        c2.metric("مجموع FRP", f"{fires['frp'].sum():,.1f} MW" if "frp" in fires else "غير متاح")
        c3.metric("ثقة عالية", int((fires["confidence_label"] == "high").sum()))
        c4.metric("آخر تاريخ رصد", str(fires["acq_date"].max()) if len(fires) else "—")

        confidence_filter = st.multiselect(
            "تصفية مستوى الثقة",
            ["high", "nominal", "low"],
            default=["high", "nominal", "low"]
        )
        shown = fires[fires["confidence_label"].isin(confidence_filter)].copy()

        center = [24.0, 45.0]
        m = folium.Map(location=center, zoom_start=5, tiles="CartoDB positron")
        folium.Rectangle(
            bounds=[[SAUDI_BBOX[1], SAUDI_BBOX[0]], [SAUDI_BBOX[3], SAUDI_BBOX[2]]],
            color="#2563eb", weight=1, fill=False, tooltip="نطاق البحث التقريبي"
        ).add_to(m)

        colors = {"high": "red", "nominal": "orange", "low": "blue"}
        for _, row in shown.iterrows():
            popup = (
                f"التاريخ: {row.get('acq_date', '—')}<br>"
                f"الوقت UTC: {row.get('acq_time', '—')}<br>"
                f"الثقة: {row.get('confidence_label', '—')}<br>"
                f"FRP: {row.get('frp', '—')} MW<br>"
                f"القمر: {row.get('satellite', '—')}"
            )
            folium.CircleMarker(
                location=[row["latitude"], row["longitude"]],
                radius=5,
                color=colors.get(row["confidence_label"], "gray"),
                fill=True, fill_opacity=0.75,
                popup=folium.Popup(popup, max_width=300)
            ).add_to(m)

        st_folium(m, use_container_width=True, height=570, returned_objects=[])
        st.subheader("سجلات البؤر الحرارية")
        display_cols = [c for c in [
            "latitude", "longitude", "acq_date", "acq_time",
            "confidence_label", "frp", "brightness", "satellite", "instrument"
        ] if c in shown.columns]
        st.dataframe(shown[display_cols], use_container_width=True, hide_index=True)
        csv = shown.to_csv(index=False).encode("utf-8-sig")
        st.download_button("تنزيل بيانات الرصد CSV", csv, "safire_active_fires.csv", "text/csv")

with tab_risk:
    st.subheader("تقدير احتمالية الحريق خلال نافذة زمنية مستقبلية")
    st.warning(
        "لا يُنتج النظام حالياً تنبؤاً تشغيلياً تلقائياً. يلزم تدريب نموذج على بيانات تاريخية "
        "موسومة، ثم توفير طبقة شبكية من المتغيرات البيئية للمملكة. لا تستخدمي هذا النموذج "
        "لاتخاذ قرارات ميدانية قبل التحقق العلمي والتشغيلي."
    )
    model_path = Path("models/fire_risk_model.joblib")
    model = load_model(model_path)
    if model is None:
        st.info("لم يتم العثور على نموذج مدرّب. راجعي README.md لتجهيز بيانات التدريب.")
    else:
        st.success("تم العثور على نموذج مدرّب.")
        metadata = {k: v for k, v in model.items() if k != "model"} if isinstance(model, dict) else {}
        st.caption(f"أفق التنبؤ: {metadata.get('horizon_hours', 24)} ساعة | حجم الخلية: {metadata.get('cell_size_m', 1000)} متر")
        if metadata.get("evaluation"):
            st.write("مؤشرات الاختبار الزمني:", metadata["evaluation"])
        st.write("ارفعي ملف CSV يحتوي على إحداثيات وخصائص كل خلية مكانية.")
        template = pd.DataFrame(columns=["latitude", "longitude"] + FEATURES)
        st.download_button(
            "تنزيل قالب بيانات شبكة التنبؤ",
            template.to_csv(index=False).encode("utf-8"),
            "risk_grid_template.csv",
            "text/csv"
        )
        uploaded = st.file_uploader("ملف شبكة التنبؤ CSV", type=["csv"])
        if uploaded:
            try:
                grid = pd.read_csv(uploaded)
                missing = [c for c in ["latitude", "longitude"] + FEATURES if c not in grid.columns]
                if missing:
                    st.error("أعمدة ناقصة: " + ", ".join(missing))
                else:
                    scored = predict_grid(model, grid)
                    st.dataframe(scored, use_container_width=True)
                    risk_map = folium.Map(location=[24.0, 45.0], zoom_start=5, tiles="CartoDB positron")
                    palette = {"منخفض": "#2ca25f", "متوسط": "#fee08b", "مرتفع": "#f46d43", "مرتفع جداً": "#a50026"}
                    for _, row in scored.iterrows():
                        folium.CircleMarker(
                            [row["latitude"], row["longitude"]],
                            radius=4,
                            color=palette.get(row["risk_class"], "#777777"),
                            fill=True,
                            fill_color=palette.get(row["risk_class"], "#777777"),
                            fill_opacity=0.7,
                            popup=f"الخطر: {row['risk_class']}<br>التقدير الاحتمالي: {row['fire_probability']:.1%}<br>الأفق: 24 ساعة"
                        ).add_to(risk_map)
                    st_folium(risk_map, use_container_width=True, height=560, returned_objects=[])
                    st.download_button(
                        "تنزيل نتائج التنبؤ",
                        scored.to_csv(index=False).encode("utf-8-sig"),
                        "safire_risk_predictions.csv",
                        "text/csv"
                    )
            except Exception as exc:
                st.error(f"تعذر تحليل الملف: {exc}")

with tab_method:
    st.subheader("كيف يعمل النظام؟")
    st.markdown("""
    1. **الرصد:** يسترجع التطبيق نقاط البؤر الحرارية من NASA FIRMS باستخدام واجهة area API.
    2. **التحقق:** يعرض الثقة وFRP ووقت الالتقاط كما وردت في المنتج الفضائي.
    3. **التنبؤ:** يقرأ نموذج Random Forest محفوظاً بعد تدريبه على بيانات تاريخية مستقلة.
    4. **العرض:** يربط احتمالات النموذج بإحداثيات الخلايا على الخريطة في مرحلة لاحقة.

    **تنبيه:** البؤرة الحرارية ليست دائماً حريق غطاء نباتي؛ قد تنتج عن مصادر حرارية أخرى.
    كما أن غياب نقطة رصد لا يثبت غياب الحريق، بسبب مرور القمر الصناعي والغطاء السحابي
    ودقة المستشعر. بيانات FIRMS ليست إنذاراً لحظياً مضموناً.
    """)
    st.markdown("مصادر البيانات: [NASA FIRMS](https://firms.modaps.eosdis.nasa.gov/) · "
                "[NASA POWER](https://power.larc.nasa.gov/)")
