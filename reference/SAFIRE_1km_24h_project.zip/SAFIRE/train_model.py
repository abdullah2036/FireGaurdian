"""
SAFIRE 24-hour fire-risk model training.

Input: one row per grid-cell/time observation, with features listed in
safire_model.FEATURES and binary target fire_next_24h.

For credible evaluation, provide a chronological split column `observation_date`.
This script trains on earlier dates and tests on the latest 20% of dates.
Random splitting is intentionally avoided to reduce temporal leakage.
Spatial holdout should additionally be performed before operational use.
"""
from pathlib import Path
import argparse
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report, average_precision_score, roc_auc_score, brier_score_loss
from sklearn.pipeline import Pipeline
from sklearn.calibration import CalibratedClassifierCV
from sklearn.utils.validation import check_is_fitted

from safire_model import FEATURES, TARGET

parser = argparse.ArgumentParser()
parser.add_argument("--input", required=True)
parser.add_argument("--output", default="models/fire_risk_model.joblib")
parser.add_argument("--date-column", default="observation_date")
args = parser.parse_args()

data = pd.read_csv(args.input)
required = FEATURES + [TARGET, args.date_column]
missing = [c for c in required if c not in data.columns]
if missing:
    raise SystemExit("أعمدة ناقصة: " + ", ".join(missing))

data[args.date_column] = pd.to_datetime(data[args.date_column], errors="coerce")
data[TARGET] = pd.to_numeric(data[TARGET], errors="coerce")
data = data.dropna(subset=[args.date_column, TARGET])
data = data[data[TARGET].isin([0, 1])].sort_values(args.date_column)

if len(data) < 500 or data[TARGET].nunique() != 2:
    raise SystemExit("يلزم 500 سجل على الأقل ووجود الفئتين 0 و1؛ الأفضل سجل تاريخي متعدد المواسم.")

unique_dates = sorted(data[args.date_column].dt.normalize().unique())
if len(unique_dates) < 5:
    raise SystemExit("يلزم خمس تواريخ مختلفة على الأقل لإجراء فصل زمني أولي.")

cut = max(1, int(len(unique_dates) * 0.8))
test_start = unique_dates[cut]
train = data[data[args.date_column].dt.normalize() < test_start]
test = data[data[args.date_column].dt.normalize() >= test_start]
if train[TARGET].nunique() != 2 or test[TARGET].nunique() != 2:
    raise SystemExit("يجب أن تحتوي عينتا التدريب والاختبار على الفئتين. راجعي تواريخ/توزيع البيانات.")

X_train = train[FEATURES].apply(pd.to_numeric, errors="coerce")
y_train = train[TARGET].astype(int)
X_test = test[FEATURES].apply(pd.to_numeric, errors="coerce")
y_test = test[TARGET].astype(int)

base = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("classifier", RandomForestClassifier(
        n_estimators=500,
        max_depth=18,
        min_samples_leaf=4,
        class_weight="balanced_subsample",
        random_state=42,
        n_jobs=-1
    ))
])
# Calibrate on a chronological validation tail from the training period.
train_dates = sorted(train[args.date_column].dt.normalize().unique())
if len(train_dates) < 4:
    raise SystemExit("فترة التدريب قصيرة جداً للمعايرة الزمنية.")
cal_start = train_dates[max(1, int(len(train_dates) * 0.8))]
fit_rows = train[train[args.date_column].dt.normalize() < cal_start]
cal_rows = train[train[args.date_column].dt.normalize() >= cal_start]
if fit_rows[TARGET].nunique() != 2 or cal_rows[TARGET].nunique() != 2:
    raise SystemExit("تعذر تكوين فترة معايرة تحتوي الفئتين؛ زيدي البيانات التاريخية.")

base.fit(fit_rows[FEATURES], fit_rows[TARGET].astype(int))
calibrated = CalibratedClassifierCV(base, method="sigmoid", cv="prefit")
calibrated.fit(cal_rows[FEATURES], cal_rows[TARGET].astype(int))

probs = calibrated.predict_proba(X_test)[:, 1]
pred = (probs >= 0.5).astype(int)
print("اختبار زمني مستقل:")
print(classification_report(y_test, pred, zero_division=0))
print("PR-AUC:", round(average_precision_score(y_test, probs), 4))
print("Brier score:", round(brier_score_loss(y_test, probs), 4))
try:
    print("ROC-AUC:", round(roc_auc_score(y_test, probs), 4))
except ValueError:
    print("ROC-AUC غير متاح.")

artifact = {
    "model": calibrated,
    "features": FEATURES,
    "horizon_hours": 24,
    "cell_size_m": 1000,
    "target": TARGET,
    "training_max_date": str(train[args.date_column].max().date()),
    "test_start_date": str(test[args.date_column].min().date()),
    "evaluation": {
        "pr_auc": float(average_precision_score(y_test, probs)),
        "brier_score": float(brier_score_loss(y_test, probs)),
    },
}
Path(args.output).parent.mkdir(parents=True, exist_ok=True)
joblib.dump(artifact, args.output)
print(f"Saved: {args.output}")
print("مهم: يلزم اختبار مكاني مستقل ومراجعة بشرية قبل أي استخدام تشغيلي.")
