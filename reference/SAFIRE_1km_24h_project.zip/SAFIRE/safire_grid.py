"""Generate a 1 km equal-area grid from an uploaded Saudi boundary GeoJSON."""
import argparse
import geopandas as gpd
from shapely.geometry import box
from shapely.prepared import prep

EQUAL_AREA_CRS = "EPSG:6933"  # global equal-area, metre units


def make_grid(boundary_file: str, output_file: str, cell_size_m: int = 1000):
    boundary = gpd.read_file(boundary_file)
    if boundary.empty:
        raise ValueError("ملف الحدود فارغ.")
    if boundary.crs is None:
        raise ValueError("يجب أن يحتوي ملف الحدود على CRS معروف.")
    boundary = boundary.to_crs(EQUAL_AREA_CRS)
    geom = boundary.geometry.union_all()
    minx, miny, maxx, maxy = geom.bounds
    prepared = prep(geom)
    rows = []
    y = miny
    while y < maxy:
        x = minx
        while x < maxx:
            cell = box(x, y, x + cell_size_m, y + cell_size_m)
            if prepared.intersects(cell):
                clipped = cell.intersection(geom)
                if not clipped.is_empty and clipped.area > 0:
                    rows.append(clipped)
            x += cell_size_m
        y += cell_size_m
    grid = gpd.GeoDataFrame({"cell_id": range(len(rows))}, geometry=rows, crs=EQUAL_AREA_CRS)
    centroids = grid.geometry.centroid
    grid["longitude"] = centroids.to_crs("EPSG:4326").x
    grid["latitude"] = centroids.to_crs("EPSG:4326").y
    grid["cell_area_km2"] = grid.geometry.area / 1_000_000
    grid.to_file(output_file, driver="GeoJSON")
    return grid


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--boundary", required=True, help="ملف حدود السعودية بصيغة GeoJSON/GPKG/Shapefile")
    parser.add_argument("--output", default="data/saudi_1km_grid.geojson")
    parser.add_argument("--cell-size", type=int, default=1000)
    args = parser.parse_args()
    result = make_grid(args.boundary, args.output, args.cell_size)
    print(f"Created {len(result):,} grid cells: {args.output}")
