import io
import requests
import pandas as pd

# Bounding box تقريبية للمملكة: west, south, east, north
SAUDI_BBOX = (34.5, 16.3, 55.7, 32.2)
FIRMS_BASE = "https://firms.modaps.eosdis.nasa.gov/api/area/csv"


def fetch_firms_fires(map_key: str, source: str, days: int = 1) -> pd.DataFrame:
    if not map_key:
        raise ValueError("NASA FIRMS MAP_KEY مطلوب.")
    if not 1 <= int(days) <= 5:
        raise ValueError("الفترة يجب أن تكون بين يوم و5 أيام (حد NASA FIRMS Area API).")
    west, south, east, north = SAUDI_BBOX
    area = f"{west},{south},{east},{north}"
    url = f"{FIRMS_BASE}/{map_key}/{source}/{area}/{int(days)}"
    response = requests.get(url, timeout=60)
    response.raise_for_status()
    if "Invalid MAP_KEY" in response.text:
        raise ValueError("مفتاح MAP_KEY غير صالح.")
    if not response.text.strip():
        return pd.DataFrame()
    return pd.read_csv(io.StringIO(response.text))


def normalize_fires(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(columns=[
            "latitude", "longitude", "acq_date", "acq_time",
            "confidence_label", "frp"
        ])

    df = df.copy()
    required = ["latitude", "longitude"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"استجابة FIRMS لا تحتوي الأعمدة المطلوبة: {missing}")

    for col in ["latitude", "longitude", "frp", "brightness"]:
        if col in df:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    if "confidence" in df:
        raw = df["confidence"].astype(str).str.lower()
        # VIIRS غالباً يورد low/nominal/high؛ بعض المنتجات قد تورد قيماً رقمية.
        df["confidence_label"] = raw.where(
            raw.isin(["low", "nominal", "high"]), "unknown"
        )
        numeric = pd.to_numeric(df["confidence"], errors="coerce")
        df.loc[numeric >= 80, "confidence_label"] = "high"
        df.loc[(numeric >= 30) & (numeric < 80), "confidence_label"] = "nominal"
        df.loc[numeric < 30, "confidence_label"] = "low"
    else:
        df["confidence_label"] = "unknown"

    # احتفظ فقط بالنقاط الواقعة داخل صندوق البحث الجغرافي
    west, south, east, north = SAUDI_BBOX
    df = df[
        df["latitude"].between(south, north)
        & df["longitude"].between(west, east)
    ]
    return df.reset_index(drop=True)
