from pathlib import Path
import joblib
import numpy as np
import pandas as pd

FEATURES = [
    "temperature_c",
    "relative_humidity_pct",
    "wind_speed_m_s",
    "precipitation_mm",
    "ndvi",
    "slope_deg",
    "landcover_code",
    "month",
]
COORDS = ["latitude", "longitude"]
TARGET = "fire_next_24h"


def load_model(path: Path):
    if not path.exists():
        return None
    artifact = joblib.load(path)
    # Support the structured artifact produced by train_model.py.
    if isinstance(artifact, dict) and "model" in artifact:
        return artifact
    # Backward compatibility for older prototype model files.
    return {"model": artifact, "features": FEATURES, "horizon_hours": 24, "cell_size_m": 1000}


def predict_grid(artifact, grid: pd.DataFrame) -> pd.DataFrame:
    model = artifact["model"] if isinstance(artifact, dict) else artifact
    features = artifact.get("features", FEATURES) if isinstance(artifact, dict) else FEATURES
    horizon = artifact.get("horizon_hours", 24) if isinstance(artifact, dict) else 24
    cell_size = artifact.get("cell_size_m", 1000) if isinstance(artifact, dict) else 1000

    required = COORDS + list(features)
    missing = [c for c in required if c not in grid.columns]
    if missing:
        raise ValueError("أعمدة ناقصة: " + ", ".join(missing))

    result = grid.copy()
    X = result[list(features)].apply(pd.to_numeric, errors="coerce")
    if X.isna().any().any():
        cols = X.columns[X.isna().any()].tolist()
        raise ValueError("قيم مفقودة أو غير رقمية في: " + ", ".join(cols))

    if not hasattr(model, "predict_proba"):
        raise ValueError("النموذج لا يدعم predict_proba؛ يلزم نموذج احتمالي معاير.")
    probabilities = model.predict_proba(X)[:, 1]
    result["fire_probability"] = np.clip(probabilities, 0, 1)
    result["risk_class"] = pd.cut(
        result["fire_probability"],
        bins=[-0.000001, 0.10, 0.30, 0.60, 1.000001],
        labels=["منخفض", "متوسط", "مرتفع", "مرتفع جداً"],
        include_lowest=True
    ).astype(str)
    result["forecast_horizon_hours"] = horizon
    result["grid_cell_size_m"] = cell_size
    return result
